package com.capg.vegetableshopping;

import static org.junit.Assert.assertEquals;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.capg.vegetableshopping.entities.VegetableDTO;
import com.capg.vegetableshopping.repository.IVegetableMgmtRepository;
import com.capg.vegetableshopping.service.IVegetableMgmtService;

@SpringBootTest
class VegetableshoppingApplicationTests 
{
	@MockBean
	IVegetableMgmtRepository vegetableRepo;
	
	@Autowired
	IVegetableMgmtService vegetableService;
	
	@Test
	public void testaddVegetable()
	{
		VegetableDTO vegetable=new VegetableDTO(1,"Tomato","Fruit","Premium",10.0,1);
		Mockito.when(vegetableRepo.saveAndFlush(vegetable)).thenReturn(vegetable);
		VegetableDTO vegetable1=vegetableService.addVegetable(vegetable);
		assertEquals(vegetable.getName(),vegetable1.getName());
	}
	
	@Test
	public void testupdateVegetable()
	{
		VegetableDTO vegetable=new VegetableDTO(1,"Tomato","Fruit","Premium",10.0,1);
		Mockito.when(vegetableRepo.saveAndFlush(vegetable)).thenReturn(vegetable);
		VegetableDTO vegetable1=vegetableService.updateVegetable(vegetable);
		assertEquals(vegetable.getName(),vegetable1.getName());
	}
	
	@Test
	public void testremoveVegetable()
	{
		VegetableDTO vegetable=new VegetableDTO(1,"Tomato","Fruit","Premium",10.0,1);
		Mockito.when(vegetableRepo.findById(1)).thenReturn(Optional.of(vegetable));
		assertEquals(null,vegetableService.removeVegetable(vegetable));
	}
	
	@Test
	public void testviewAllVegetables()
	{
		VegetableDTO vegetable=new VegetableDTO(1,"Tomato","Fruit","Premium",10.0,1);
		VegetableDTO vegetable1=new VegetableDTO(2,"Potato","Root","NonPremium",20.0,2);
		List<VegetableDTO> vegetableList=new ArrayList<VegetableDTO>();
		vegetableList.add(vegetable);
		vegetableList.add(vegetable1);
		Mockito.when(vegetableRepo.findAll()).thenReturn(vegetableList);
		assertEquals(2,vegetableService.viewAllVegetables().size());	
	}
	
	@Test
	public void testviewVegetableList()
	{
		Mockito.when(vegetableRepo.findByCategory("Premium")).thenReturn
		(Stream.of(new VegetableDTO(1,"Tomato","Fruit","Premium",20.0,2)).collect(Collectors.toList()));
	}
	
	@Test
	public void testviewVegetableByName()
	{
		Mockito.when(vegetableRepo.findByName("Tomato")).thenReturn
		(Stream.of(new VegetableDTO(1,"Tomato","Fruit","Premium",20.0,2)).collect(Collectors.toList()));
	}
}
