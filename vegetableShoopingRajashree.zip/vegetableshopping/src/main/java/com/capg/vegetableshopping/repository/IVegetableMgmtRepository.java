package com.capg.vegetableshopping.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.vegetableshopping.entities.VegetableDTO;
@Repository
public interface IVegetableMgmtRepository extends JpaRepository<VegetableDTO,Integer> 
{

	List<VegetableDTO> findByCategory(String category);
	
	List<VegetableDTO> findByName(String name);
	
}
