package com.capg.vegetableshopping.service;

import java.util.List;

import com.capg.vegetableshopping.entities.Feedback;

public interface IFeedbackService {

	public Feedback addFeedback(Feedback fdk);
	public List<Feedback> viewAllFeedbacks(int vegetableId);

}
