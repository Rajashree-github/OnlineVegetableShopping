package com.capg.vegetableshopping.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capg.vegetableshopping.entities.VegetableDTO;
import com.capg.vegetableshopping.service.IVegetableMgmtService;

@RestController
@RequestMapping("/veggies")
public class VegetableDTOController 
{
	@Autowired
	private IVegetableMgmtService vegetableService;
	
	@PostMapping("add")
	public ResponseEntity<VegetableDTO> addVegetable(@Valid @RequestBody VegetableDTO dto)//working
	{
		VegetableDTO vegetable= vegetableService.addVegetable(dto);
		if(vegetable==null)
		{
			return new ResponseEntity("Sorry! vegetables you want to update is not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<VegetableDTO>(vegetable, HttpStatus.OK);
	}
	

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("update")
	public ResponseEntity<VegetableDTO> updateVegetable(@RequestBody VegetableDTO dto)//working
	{
		VegetableDTO vegetable1= vegetableService.updateVegetable(dto);
		if(vegetable1==null)
		{
			return new ResponseEntity("Sorry! vegetables you want to update is not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<VegetableDTO>(vegetable1, HttpStatus.OK);
		}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@DeleteMapping("delete")
	public ResponseEntity<VegetableDTO> removeVegetable(@RequestBody VegetableDTO dto)
	{
		VegetableDTO vegetable2=vegetableService.removeVegetable(dto);
		if(vegetable2==null)
		{
			return new ResponseEntity("Vegetables removed!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<VegetableDTO>(vegetable2,HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("viewall")
	public ResponseEntity<List<VegetableDTO>> viewAllVegetables() 
	{
		List<VegetableDTO> vegetable4= vegetableService.viewAllVegetables();
		if(vegetable4.isEmpty()|| vegetable4==null) 
		{
			return new ResponseEntity("Sorry!! no veggies are available to view!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<VegetableDTO>>(vegetable4, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/viewcat/{category}")
	public ResponseEntity<List<VegetableDTO>> viewVegetableList(@PathVariable("category")String category) 
	{
		List<VegetableDTO> vegetable5= vegetableService.viewVegetableList(category);
		if(vegetable5.isEmpty()||vegetable5==null) 
		{
			return new ResponseEntity("Sorry!! no veggies are available to view!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<VegetableDTO>>(vegetable5, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/viewname/{name}")
	public ResponseEntity<List<VegetableDTO>> viewVegetableByName(@PathVariable("name")String name) 
	{
		List<VegetableDTO> vegetable6= vegetableService.viewVegetableByName(name);
		if(vegetable6.isEmpty()||vegetable6==null) 
		{
			return new ResponseEntity("Sorry!! no veggies are available to view!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<VegetableDTO>>(vegetable6, HttpStatus.OK);
	}
}
