package com.capg.vegetableshopping.service;

public interface IBillingService {

}
