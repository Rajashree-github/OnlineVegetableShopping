package com.capg.vegetableshopping.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capg.vegetableshopping.entities.VegetableDTO;
import com.capg.vegetableshopping.exception.NotFoundException;
import com.capg.vegetableshopping.repository.IVegetableMgmtRepository;
@Service
public class VegetableMgmtServiceImpl implements IVegetableMgmtService
{
	@Autowired
	private IVegetableMgmtRepository vegetableRepo;

	public VegetableDTO addVegetable(VegetableDTO dto) 
	{
		VegetableDTO vegetable=vegetableRepo.saveAndFlush(dto);
		if(vegetable==null)
		{
			return null;
		}
		return vegetable;
	}
	public VegetableDTO updateVegetable(VegetableDTO dto)
	{
		VegetableDTO vegetable=vegetableRepo.saveAndFlush(dto);
		return vegetable;
	}
	public VegetableDTO removeVegetable(VegetableDTO dto)
	{
		Optional<VegetableDTO> vegetable=vegetableRepo.findById(dto.getVegId());
		if(vegetable.isPresent())
		{
			vegetableRepo.delete(dto);
		}
		else
		{
			throw new NotFoundException("cannot find Vegetable");
		}
		return null;
	}
	
	public List<VegetableDTO> viewAllVegetables() 
	{
		List<VegetableDTO> vegetablelist=null;
		vegetablelist=vegetableRepo.findAll();
		if(vegetablelist.isEmpty() ||vegetablelist==null)
		{
			throw new NotFoundException("No vegetables to view!");
		}
		return vegetablelist;
	}
	public List<VegetableDTO> viewVegetableList(String category) 
	{
		List<VegetableDTO> vegetablelist=null;
		vegetablelist=vegetableRepo.findByCategory(category);
		if(vegetablelist.isEmpty() || vegetablelist==null)
		{
			throw new NotFoundException("No vegetables with "+category+" category");
		}
		return vegetablelist;
	}
	public List<VegetableDTO> viewVegetableByName(String name)  
	{
		List<VegetableDTO> vegetablelist=null;
		vegetablelist=vegetableRepo.findByName(name);
		if(vegetablelist.isEmpty() || vegetablelist==null)
		{
			throw new NotFoundException("No "+name+"'s available");
		}
		return vegetablelist;
	}
}
