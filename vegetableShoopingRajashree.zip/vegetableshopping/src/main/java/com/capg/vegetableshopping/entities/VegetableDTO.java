package com.capg.vegetableshopping.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import com.sun.istack.NotNull;


@Entity
@Table
public class VegetableDTO {
	
	@Id
	@GeneratedValue
	@Column
	private int vegId;
	@NotNull
	@Size(min=2, message="Name should be have atleast 3 characters!")
	@Column
	private String name;
	@NotNull
	@Size(min=2, message="Please specify type!")
	@Column
	private String type;
	@NotNull
	@Size(min=2, message="Please specify the category!")
	@Column
	private String category;
	@NotNull
	@Min(value = 1,message = "price minimum is 1")
    @Max(value =  1000,message = "price maximum is 1000")
	@Column
	private double price;
	@Column
	private int quantity;

	public int getVegId() {
		return vegId;
	}
	public void setVegId(int vegId) {
		this.vegId = vegId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public VegetableDTO(int vegId, String name, String type, String category, double price, int quantity) 
	{
		super();
		this.vegId = vegId;
		this.name = name;
		this.type = type;
		this.category = category;
		this.price = price;
		this.quantity = quantity;
	}
	public VegetableDTO()
	{
		
	}
	
}
