package com.capg.vegetableshopping.repository;

import java.util.List;

import com.capg.vegetableshopping.entities.Customer;

public interface ICustomerRepository {

	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public Customer removeCustomer(Customer customer);
	public Customer viewCustomer(Customer customer);
	public List<Customer> viewCustomerList(String location);
}
