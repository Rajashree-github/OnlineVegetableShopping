package com.capg.vegetableshopping.repository;

public interface IBillingRepository {

}
