package com.capg.vegetableshopping.controller;

import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javassist.NotFoundException;
@Order(1)
@ControllerAdvice
@RestController
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

	@ResponseBody
	@ResponseStatus(value=HttpStatus.CONFLICT)
	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<Object> NotFoundExceptionHandler(NotFoundException e)
	{
		//HttpStatus status = HttpStatus.BAD_REQUEST;
		
		//ErrorMessage payload=new ErrorMessage(e.getMessage(),status);
		return new ResponseEntity<Object>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
}
