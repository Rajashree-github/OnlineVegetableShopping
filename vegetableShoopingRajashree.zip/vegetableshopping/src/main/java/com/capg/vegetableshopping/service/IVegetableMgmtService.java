package com.capg.vegetableshopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capg.vegetableshopping.entities.VegetableDTO;
@Service
public interface IVegetableMgmtService {

	public VegetableDTO addVegetable(VegetableDTO dto);
	public VegetableDTO updateVegetable(VegetableDTO dto);
	public VegetableDTO removeVegetable(VegetableDTO dto);
	public List<VegetableDTO> viewAllVegetables();
	public List<VegetableDTO> viewVegetableList(String category);
	public List<VegetableDTO> viewVegetableByName(String name);
}
