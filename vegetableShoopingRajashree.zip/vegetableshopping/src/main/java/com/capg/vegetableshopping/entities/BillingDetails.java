package com.capg.vegetableshopping.entities;

public class BillingDetails {

	private int billingId;
	private int orderId;
	private String transactionMode;
	private String transactionDate;
	private String tranactionStatus;

}
